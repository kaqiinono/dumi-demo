import GroupIcon from "./Icon/GroupIcon" ;

export {
    GroupIcon
}
// @ts-ignore
export * from './version';
