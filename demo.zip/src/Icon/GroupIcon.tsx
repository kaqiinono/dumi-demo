import SvgIcon from './SvgIcon';
import { ReactComponent as IconSvg } from './icon.svg';
import React from 'react'

const GroupIcon = (props:any) => <SvgIcon {...props} IconSvg={IconSvg} />;
export default GroupIcon;
