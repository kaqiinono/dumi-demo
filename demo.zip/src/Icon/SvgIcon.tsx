import React from 'react';
import Icon from './Icon';

const SvgIcon = ({ className, width, height, viewBox, IconSvg, fill }: any) => {
    const svgProps = {
        width: width || 24,
        height: height || 24,
        fill: 'red' || 'currentColor',
        viewBox,
    }
  return (
    <Icon
        {...svgProps}
      className={className}
      component={IconSvg}
    />
  );
};

export default SvgIcon;
