export const version = {
  "kaqiinono-icons": "2.6.5",
};
