# @ant-design/pro-components

> @ant-design/pro-components.

See our website [@ant-design/pro-components](https://procomponent.ant.design/) for more information.

## Install

Using npm:

```bash
$ npm install --save  @ant-design/pro-components
```

or using yarn:

```bash
$ yarn add @ant-design/pro-components
```
